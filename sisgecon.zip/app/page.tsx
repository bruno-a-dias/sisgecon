import { LoginForm } from "@/components/login-form"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4 bg-background">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-primary mb-2">SISGECON</h1>
          <p className="text-muted-foreground">Sistema de Gerenciamento de Condomínio</p>
        </div>
        <LoginForm />
      </div>
    </main>
  )
}
